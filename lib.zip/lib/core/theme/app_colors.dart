import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFFBFA054);
  static const Color secondaryColor = Color(0xFFF7F8F9);
  static const Color accentColor = Color(0xFF1A1A1A);
  static const Color hintTextColor = Color(0xffE8ECF4);
  static const Color hintTextDescriptionColor = Color(0xff8391A1);
  static const Color bookCardBackgroundColor = Color(0xFFF5EFE1);
  static const Color darkTextColor = Color(0xFF2F2F2F);
}
