import 'package:bookia_store/core/utils/assets.gen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

class BookDetailsAppBar extends StatelessWidget {
  const BookDetailsAppBar({super.key});

  @override
  Widget build(BuildContext context) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      _ActionIcon(
        assetPath: Assets.icons.back,
        onTap: () => Navigator.pop(context),
      ),
      _ActionIcon(
        assetPath: Assets.icons.bookmark,
        onTap: () {
          // TODO: add to wishlist
        },
      ),
    ],
  );
}

class _ActionIcon extends StatelessWidget {
  const _ActionIcon({required this.assetPath, required this.onTap});

  final String assetPath;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(12.r),
    child: Container(
      width: 41.w,
      height: 41.h,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Center(
        child: SvgPicture.asset(
          assetPath,
          width: 20.w,
          height: 20.h,
        ),
      ),
    ),
  );
}
