import 'package:bookia_store/features/home/Presentation/widget/book_details_app_bar.dart';
import 'package:bookia_store/features/home/Presentation/widget/book_details_bottom_bar.dart';
import 'package:bookia_store/features/home/Presentation/widget/book_details_info.dart';
import 'package:bookia_store/features/home/data/models/best_seller_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BookDetails extends StatelessWidget {
  const BookDetails({super.key, required this.product});

  final BookProduct product;

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.white,
    body: SafeArea(
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                horizontal: 20.w,
                vertical: 12.h,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const BookDetailsAppBar(),
                  SizedBox(height: 20.h),
                  BookDetailsInfo(product: product),
                ],
              ),
            ),
          ),
          BookDetailsBottomBar(product: product),
        ],
      ),
    ),
  );
}
