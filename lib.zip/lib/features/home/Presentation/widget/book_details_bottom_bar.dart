import 'package:bookia_store/core/theme/app_colors.dart';
import 'package:bookia_store/core/theme/app_strings.dart';
import 'package:bookia_store/core/utils/fonts.gen.dart';
import 'package:bookia_store/features/home/data/models/best_seller_model.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BookDetailsBottomBar extends StatelessWidget {
  const BookDetailsBottomBar({super.key, required this.product});

  final BookProduct product;

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
    decoration: BoxDecoration(
      color: Colors.white,
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.05),
          blurRadius: 10,
          offset: const Offset(0, -4),
        ),
      ],
    ),
    child: Row(
      children: [
        _PriceLabel(price: product.price ?? '0'),
        SizedBox(width: 16.w),
        Expanded(child: _AddToCartButton(onPressed: () {})),
      ],
    ),
  );
}

class _PriceLabel extends StatelessWidget {
  const _PriceLabel({required this.price});

  final String price;

  @override
  Widget build(BuildContext context) => Text(
    '₹$price',
    style: TextStyle(
      fontFamily: FontFamily.dMSerifDisplay,
      fontSize: 22.sp,
      fontWeight: FontWeight.w400,
      color: AppColors.darkTextColor,
    ),
  );
}

class _AddToCartButton extends StatelessWidget {
  const _AddToCartButton({required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) => ElevatedButton(
    onPressed: onPressed,
    style: ElevatedButton.styleFrom(
      backgroundColor: AppColors.accentColor,
      foregroundColor: Colors.white,
      elevation: 0,
      padding: EdgeInsets.symmetric(vertical: 16.h),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),
    ),
    child: Text(
      AppStrings.addToCart.tr(),
      style: TextStyle(
        fontFamily: FontFamily.dMSerifDisplay,
        fontSize: 16.sp,
      ),
    ),
  );
}
