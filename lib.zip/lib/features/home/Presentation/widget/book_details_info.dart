import 'package:bookia_store/core/theme/app_colors.dart';
import 'package:bookia_store/core/theme/app_strings.dart';
import 'package:bookia_store/core/utils/fonts.gen.dart';
import 'package:bookia_store/features/home/data/models/best_seller_model.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BookDetailsInfo extends StatelessWidget {
  const BookDetailsInfo({super.key, required this.product});

  final BookProduct product;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      _BookCover(imageUrl: product.image ?? ''),
      SizedBox(height: 20.h),
      _BookTitle(title: product.name ?? ''),
      SizedBox(height: 6.h),
      _BookCategory(),
      SizedBox(height: 16.h),
      _BookDescription(description: product.description ?? ''),
    ],
  );
}

class _BookCover extends StatelessWidget {
  const _BookCover({required this.imageUrl});

  final String imageUrl;

  @override
  Widget build(BuildContext context) => Center(
    child: ClipRRect(
      borderRadius: BorderRadius.circular(8.r),
      child: Image.network(
        imageUrl,
        height: 220.h,
        width: 150.w,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          height: 220.h,
          width: 150.w,
          decoration: BoxDecoration(
            color: AppColors.bookCardBackgroundColor,
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: Icon(
            Icons.book_rounded,
            size: 64.w,
            color: AppColors.primaryColor,
          ),
        ),
      ),
    ),
  );
}

class _BookTitle extends StatelessWidget {
  const _BookTitle({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) => Text(
    title,
    textAlign: TextAlign.center,
    style: TextStyle(
      fontFamily: FontFamily.dMSerifDisplay,
      fontSize: 24.sp,
      fontWeight: FontWeight.w400,
      color: AppColors.darkTextColor,
    ),
  );
}

class _BookCategory extends StatelessWidget {
  const _BookCategory();

  @override
  Widget build(BuildContext context) => Text(
    AppStrings.bookType.tr(),
    style: TextStyle(
      fontFamily: FontFamily.dMSerifDisplay,
      fontSize: 14.sp,
      color: AppColors.primaryColor,
    ),
  );
}

class _BookDescription extends StatelessWidget {
  const _BookDescription({required this.description});

  final String description;

  @override
  Widget build(BuildContext context) => Align(
    alignment: AlignmentDirectional.centerStart,
    child: Text(
      description,
      style: TextStyle(
        fontSize: 14.sp,
        height: 1.6,
        color: AppColors.darkTextColor.withValues(alpha: 0.7),
      ),
    ),
  );
}
